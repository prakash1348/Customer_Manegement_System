var arrCustomer = [];

function displayCustomer(e) {
    var table = document.getElementById("table");
    table.innerHTML = "";
    arrCustomer.forEach((cus) => {
        let tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${cus.id}</td>
            <td>${cus.name}</td>
            <td>${cus.address}</td>
            <td>${cus.number}</td>
        `;
        table.appendChild(tr);
    });
}

function refreshInput(e){
    document.getElementById("textId").value = "";
    document.getElementById("textName").value = "";
    document.getElementById("textAddress").value = "";
    document.getElementById("textNumber").value = "";
}

function addCustomer_click(e) {
    const id = document.getElementById("textId");
    const name = document.getElementById("textName");
    const address = document.getElementById("textAddress");
    const number = document.getElementById("textNumber");

    if (!id.value || !name.value || !address.value || !number.value) {
        alert("Please fill all details of customer");
    } else {
        var cus = {
            id: id.value,
            name: name.value,
            address: address.value,
            number: number.value
        }
        addCustomer(cus);
        refreshInput();
    }
}

function searchCustomer_click(e) {
    const id = document.getElementById("textId").value;
    if (!id) {
        alert("Please enter customer ID to search.");
        return;
    }
    searchCustomer(id);
}

function modifyCustomer_click(e) {
    const id = document.getElementById("textId");
    const name = document.getElementById("textName");
    const address = document.getElementById("textAddress");
    const number = document.getElementById("textNumber");
    if (!id || !name || !address || !number) {
        alert("Please enter complete details for modification.");
        return;
    }
    let cusModify = {
        id: id.value,
        name: name.value,
        address: address.value,
        number: number.value
    }
    modifyCustomer(cusModify);
    refreshInput();
}

function deletCustomer_click(e) {
    let cusId = document.getElementById("textId").value;
    if (!cusId) {
        alert("Please enter customer ID to delete.");
        return;
    }
    deletCustomer(cusId);
    refreshInput();
}

document.getElementById("btnAddCustomer").addEventListener("click", addCustomer_click);
document.getElementById("btnSearchCustomer").addEventListener("click", searchCustomer_click);
document.getElementById("btnModifyCustomer").addEventListener("click", modifyCustomer_click);
document.getElementById("btnDeletCustomer").addEventListener("click", deletCustomer_click);


function addCustomer(cus) {
    cus.id = cus.id.trim();
    let exist = arrCustomer.some(cust => cust.id === cus.id);
    if (exist) {
        alert("this ID already exist!");
    } else {
        arrCustomer.push(cus);
        alert("Customer details add succesfuly");
        displayCustomer()
    }
}

function searchCustomer(cus) {
    cus = cus.trim();
    let customer = arrCustomer.find(cust => cust.id == cus);
    if (customer) {
        document.getElementById("textName").value = customer.name;
        document.getElementById("textAddress").value = customer.address;
        document.getElementById("textNumber").value = customer.number;
    } else {
        alert("customer not found !");
    }
}

function modifyCustomer(cus) {
    const index = arrCustomer.findIndex(cust => cust.id === cus.id);
    if (index !== -1) {
        arrCustomer[index] = {
            ...arrCustomer[index],
            name: cus.name || arrCustomer[index].name,
            address: cus.address || arrCustomer[index].address,
            number: cus.number || arrCustomer[index].number
        };
        alert("Modified successfully");
        displayCustomer();
    } else {
        alert("Customer not found");
    }
}

function deletCustomer(cusId) {
    const index = arrCustomer.findIndex(cust => cust.id == cusId);
    if (index !== -1) {
        arrCustomer.splice(index, 1);
        alert("Customer deleted successfully!");
        displayCustomer();
    } else {
        alert("Customer Not Found!");
    }
}
